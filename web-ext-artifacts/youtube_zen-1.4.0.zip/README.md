Firefox Browser Extension to hide or show the Youtube video controls when paused

Build using 
  :: 'web-ext build'
 or
  :: 'web-ext sign --api-key=user:XXX --api-secret=YYY'